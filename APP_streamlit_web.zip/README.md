# AI Rehab Streamlit App

This is the browser-camera version of the original OpenCV desktop app.

## Local run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud

Upload this folder to GitHub, then create a new app on Streamlit Community Cloud.
Set the main file path to:

```text
app.py
```
